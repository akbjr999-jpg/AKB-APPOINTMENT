import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
}

const OWNER_EMAIL = Deno.env.get('OWNER_EMAIL') ?? 'akbjr999@gmail.com'
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
const RESEND_FROM_EMAIL = Deno.env.get('RESEND_FROM_EMAIL') ?? 'AKB <onboarding@resend.dev>'
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

const SCHEDULE: Record<string, string[]> = {
  MON: ['09 AM','11 AM','13 PM','15 PM','17 PM'],
  TUE: ['10 AM','13 PM','15 PM','17 PM'],
  WED: ['09 AM','11 AM','15 PM','16 PM'],
  THU: ['11 AM','13 PM','14 PM','15 PM','17 PM'],
  FRI: ['09 AM','11 AM','13 PM','15 PM'],
}
const TIME24: Record<string, string> = {
  '09 AM':'09:00:00', '10 AM':'10:00:00', '11 AM':'11:00:00',
  '13 PM':'13:00:00', '14 PM':'14:00:00', '15 PM':'15:00:00',
  '16 PM':'16:00:00', '17 PM':'17:00:00',
}
const DOW: Record<string, number> = { MON:1, TUE:2, WED:3, THU:4, FRI:5 }

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: corsHeaders })

function dayCode(date: string) {
  const d = new Date(`${date}T00:00:00Z`)
  const n = d.getUTCDay()
  return Object.entries(DOW).find(([, v]) => v === n)?.[0] ?? null
}

function validateDate(date: unknown) {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return 'Invalid date.'
  const today = new Date().toISOString().slice(0, 10)
  if (date < today) return 'Past dates cannot be booked.'
  return null
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]!))
}

async function sendEmail(to: string[], subject: string, html: string) {
  if (!RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured.')
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: RESEND_FROM_EMAIL, to, subject, html }),
  })
  const data = await response.json()
  if (!response.ok) throw new Error(data?.message || `Resend error ${response.status}`)
  return data
}

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ message: 'POST only.' }, 405)
  if (!SERVICE_ROLE_KEY) return json({ message: 'Server is not configured: missing SUPABASE_SERVICE_ROLE_KEY.' }, 500)

  try {
    const body = await req.json()
    const action = body?.action
    const supabaseAdmin = createClient(Deno.env.get('SUPABASE_URL')!, SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
    })

    if (action === 'availability') {
      const date = body?.date
      const dateError = validateDate(date)
      if (dateError) return json({ message: dateError }, 400)
      const day = dayCode(date)
      if (!day) return json({ booked: [] })

      const { data, error } = await supabaseAdmin
        .from('bookings')
        .select('appointment_time')
        .eq('appointment_date', date)
        .eq('status', 'confirmed')
      if (error) throw error
      return json({ booked: (data ?? []).map((r: any) => String(r.appointment_time).slice(0,8)) })
    }

    if (action === 'create') {
      const name = String(body?.name ?? '').trim()
      const email = String(body?.email ?? '').trim().toLowerCase()
      const phone = String(body?.phone ?? '').trim()
      const date = body?.date
      const timeDisplay = String(body?.time ?? '').trim()

      if (name.length < 2 || name.length > 120) return json({ message: 'Please enter a valid name.' }, 400)
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ message: 'Please enter a valid email.' }, 400)
      if (!/^[0-9+()\s-]{7,20}$/.test(phone)) return json({ message: 'Please enter a valid phone number.' }, 400)
      const dateError = validateDate(date)
      if (dateError) return json({ message: dateError }, 400)

      const day = dayCode(date)
      if (!day || !SCHEDULE[day].includes(timeDisplay)) return json({ message: 'That appointment time is not available for the selected date.' }, 400)
      const time24 = TIME24[timeDisplay]

      const { data: existing, error: existingError } = await supabaseAdmin
        .from('bookings')
        .select('id,status')
        .eq('appointment_date', date)
        .eq('appointment_time', time24)
        .in('status', ['confirmed','completed'])
        .maybeSingle()
      if (existingError) throw existingError
      if (existing) return json({ message: 'This appointment time has already been booked.' }, 409)

      const { data: booking, error: insertError } = await supabaseAdmin
        .from('bookings')
        .insert({
          name, email, phone,
          appointment_date: date,
          appointment_time: time24,
          time_display: timeDisplay,
          status: 'confirmed',
          email_status: 'pending',
        })
        .select('id,name,email,phone,appointment_date,appointment_time,time_display,status,created_at')
        .single()

      if (insertError) {
        if (insertError.code === '23505') return json({ message: 'This appointment time has already been booked.' }, 409)
        throw insertError
      }

      const safeName = escapeHtml(name)
      const safeEmail = escapeHtml(email)
      const safePhone = escapeHtml(phone)
      const prettyDate = new Date(`${date}T00:00:00Z`).toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric', timeZone:'UTC' })
      const safeDate = escapeHtml(prettyDate)
      const safeTime = escapeHtml(timeDisplay)
      const safeId = escapeHtml(booking.id)

      let emailStatus = 'sent'
      let emailError: string | null = null
      try {
        await sendEmail([OWNER_EMAIL], 'New Appointment Booking - AKB', `
          <h2>New appointment received</h2>
          <p><strong>Customer Name:</strong> ${safeName}</p>
          <p><strong>Customer Email:</strong> ${safeEmail}</p>
          <p><strong>Customer Phone:</strong> ${safePhone}</p>
          <p><strong>Appointment Date:</strong> ${safeDate}</p>
          <p><strong>Appointment Time:</strong> ${safeTime}</p>
          <p><strong>Booking ID:</strong> ${safeId}</p>
        `)
        await sendEmail([email], 'Your Appointment is Confirmed - AKB', `
          <h2>Your appointment is confirmed</h2>
          <p>Hello ${safeName},</p>
          <p><strong>Date:</strong> ${safeDate}</p>
          <p><strong>Time:</strong> ${safeTime}</p>
          <p><strong>Booking ID:</strong> ${safeId}</p>
          <p>Thank you.<br>AKB</p>
        `)
      } catch (mailError) {
        emailStatus = 'failed'
        emailError = String(mailError?.message ?? mailError)
      }

      await supabaseAdmin.from('bookings').update({ email_status: emailStatus, email_error: emailError }).eq('id', booking.id)

      return json({ success: true, booking, email_status: emailStatus })
    }

    return json({ message: 'Unknown action.' }, 400)
  } catch (error) {
    console.error(error)
    return json({ message: 'Unexpected server error.' }, 500)
  }
})
