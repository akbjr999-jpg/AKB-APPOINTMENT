-- Retouch appointment booking database
create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text not null,
  appointment_date date not null,
  appointment_time time not null,
  time_display text not null,
  status text not null default 'confirmed' check (status in ('confirmed','completed','cancelled')),
  email_status text not null default 'pending' check (email_status in ('pending','sent','failed')),
  email_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (appointment_date, appointment_time)
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.bookings enable row level security;
alter table public.admin_users enable row level security;

-- Admin users may see their own admin_users row. No public access.
drop policy if exists "admins can see own admin row" on public.admin_users;
create policy "admins can see own admin row"
on public.admin_users for select
to authenticated
using (user_id = auth.uid());

-- Helper used by bookings policies. SECURITY DEFINER avoids recursive policy checks.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_users a where a.user_id = auth.uid()
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Only authenticated administrators can read/update bookings.
drop policy if exists "admins can read bookings" on public.bookings;
create policy "admins can read bookings"
on public.bookings for select
to authenticated
using (public.is_admin());

drop policy if exists "admins can update bookings" on public.bookings;
create policy "admins can update bookings"
on public.bookings for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Public visitors do NOT get direct SELECT/INSERT access. The Edge Function performs
-- validated booking creation using the server secret, which also protects customer PII.
revoke all on table public.bookings from anon, authenticated;
grant select, update on table public.bookings to authenticated;

-- Keep updated_at current when an admin changes status.
create or replace function public.set_bookings_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists bookings_set_updated_at on public.bookings;
create trigger bookings_set_updated_at
before update on public.bookings
for each row execute function public.set_bookings_updated_at();

-- The Data API does not need to expose INSERT to browsers; the Edge Function uses
-- the service-role key. This is intentional.
